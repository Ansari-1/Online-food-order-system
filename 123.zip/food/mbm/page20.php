<?php
if(isset($_POST['c1']))
echo "you like sports<br>";
else
echo "you dont like sports<br>";
if(isset($_POST['c2']))
echo "you like music<br>";
else
echo "you dont like music<br>";
?>