
<html>
<head>
<title>add to cart</title>
</head>
<form name=frm method=post action=addtocart.php>
<center><table>
<caption>add to cart</caption>
<Tr>
<td>Quantity</td>
<td><input type=text name=qt></td>
</tr>
</table>
<input type=submit name=sbm value=back_to_select>
<input type=submit name=sbm value=add>
<input type=submit name=sbm value=confirm>
</center>
</form>
</html>
<?php
$cn=mysql_connect("localhost","root");
mysql_select_db("food",$cn);
session_start();
if(isset($_POST['sbm']))
{
if($_POST['sbm']=="add")
{
$amt=$_POST['qt']*$_SESSION['rt'];
$gam=$amt*$_SESSION['gst']/100;
$namt=$amt+$gam+$gam;
$dt=date("Y-m-d");
$id=$_SESSION['ordid'];
echo $id,$dt,$amt,$gam,$namt;
$sql="insert into order1 values('$_SESSION[ordid]','$dt','$_SESSION[mi]','$_POST[qt]','$_SESSION[ft1]','$_SESSION[rt]','$amt','$gam','$gam','$namt')";
mysql_query($sql);
header("location:http://localhost/food/order2.php");
}
else
if($_POST['sbm']=="back_to_select")
header("location:http://localhost/food/order2.php");
else
header("location:http://localhost/food/confirmation.php");
}
?>