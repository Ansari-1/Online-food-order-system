<?php
$a=1;
while($a<=10)
{
echo "$a<br>";
$a=$a+1;
}
?>