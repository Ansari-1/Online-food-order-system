<?php
for($a=1;$a<=10;$a++)
{
for($b=1;$b<=10;$b++)
{
$c=$a*$b;
echo "$c ";
}
echo "<br>";
}
?>