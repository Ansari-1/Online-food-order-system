<?php
$v=$_POST['vt'];
$r=$_POST['rt'];
$d=$_POST['dt'];
echo "<center><table>";
echo "<tr><td>virat</td><td valign=bottom><img src=pict1.bmp width=$v height=20></td><td>$v</td></tr>";
echo "<tr><td>rohit</td><td valign=bottom><img src=pict1.bmp width=$r height=20></td><td>$r</td></tr>";
echo "<tr><td>dhoni</td><td valign=bottom><img src=pict1.bmp width=$d height=20></td><td>$d</td></tr>";
echo "</table></center>";
?>