<?php
echo "your caste is '$_POST[cs]'";
?>