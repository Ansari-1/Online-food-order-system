
<html>
<head>
<title>menu</title>
</head>
<form name=frm method=post action=confirmorder.php>
<input type=submit name=sbm value=display>
</form>
</html>

<?php
if(isset($_POST['sbm']))
{
$cn=mysql_connect("localhost","root");
mysql_select_db("food",$cn);
if($_POST['sbm']=="display")
{
$sql="select * from confirmation";
echo "<center><table border=1>";
echo "<caption>confirm information</caption>";
echo "<tr>";
echo "<th>orderid</th>";
echo "<th>confirm time</th>";
echo "<th>expdeltime</th>";
echo "<th>total amount</th>";
echo "<th>customer name</th>";
echo "<th>customer address</th>";
echo "<th>mob. no.</th>";
echo "<th>email</th>";
echo "<th>pay type</th>";
echo "<th>cgst</th>";
echo "<th>sgst</th>";
echo "<th>netamt</th>";
echo "<th>status</th>";
echo "</tr>";
$result=mysql_query($sql,$cn);
while($row=mysql_fetch_array($result))
{
echo "<tr>";
echo "<td>$row[0]</td>";
echo "<td>$row[1]</td>";
echo "<td>$row[2]</td>";
echo "<td>$row[3]</td>";
echo "<td>$row[4]</td>";
echo "<td>$row[5]</td>";
echo "<td>$row[6]</td>";
echo "<td>$row[7]</td>";
echo "<td>$row[8]</td>";
echo "<td>$row[9]</td>";
echo "<td>$row[10]</td>";
echo "<td>$row[11]</td>";
echo "<td>$row[12]</td>";
echo "</tr>";
}
echo "</table></center>";
}
}
?>