<?php
session_start();
$cn=mysql_connect("localhost","root");
mysql_select_db("food",$cn);
$sql="select * from menu order by type1";
$result=mysql_query($sql);
echo "<table>";
echo "<tr>";
$c=1;
while($row=mysql_fetch_array($result))
{
echo "<td><a href=preaddtocart.php?mi=$row[0]&ft=$row[1]&rt=$row[5]&gst=$row[7]><img src=$row[8] height=100 width=100 border=1><br>$row[2]<br>$row[4]<br>$row[5] Rs.</a></td>";
$c=$c+1;
if($c>4)
{
$c=1;
echo "</tr>";
echo "<tr>";
}
}
?>
<html>
<body>
<form name=frm method=post action=confirmation.php>
<center>
<input type=submit name=sbm11 value=confirm>
</center>
</form>
</body>
</html>