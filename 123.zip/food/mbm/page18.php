<?php
echo $_POST['ad'];
?>