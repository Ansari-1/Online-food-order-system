
<html>
<head>
<title>delivery</title>
</head>
<form name=frm method=post action=deliveryorder.php>
<input type=submit name=sbm value=display>
</form>
</html>

<?php
if(isset($_POST['sbm']))
{
$cn=mysql_connect("localhost","root");
mysql_select_db("food",$cn);
if($_POST['sbm']=="display")
{
$sql="select * from delivery";
echo "<center><table border=1>";
echo "<caption>delivery information</caption>";
echo "<tr>";
echo "<th>delivery no</th>";
echo "<th>delivery time</th>";
echo "<th>order id</th>";
echo "<th>customer name</th>";
echo "<th>net amount</th>";
echo "</tr>";
$result=mysql_query($sql,$cn);
while($row=mysql_fetch_array($result))
{
echo "<tr>";
echo "<td>$row[0]</td>";
echo "<td>$row[1]</td>";
echo "<td>$row[2]</td>";
echo "<td>$row[3]</td>";
echo "<td>$row[4]</td>";
echo "</tr>";
}
echo "</table></center>";
}
}
?>