<?php
echo date("h:mi:s");
?>