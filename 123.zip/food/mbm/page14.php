<?php
$n=$_POST['n1'];
for($a=1;$a<=$n;$a++)
{
echo "$a<br>";
}
?>