<?php
if(isset($_POST['r1']))
echo "your gender is '$_POST[r1]'";
else
echo "select your gender";
?>