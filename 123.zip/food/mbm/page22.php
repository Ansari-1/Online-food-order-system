<?php
$v=$_POST['vt'];
$r=$_POST['rt'];
$d=$_POST['dt'];
echo "<img src=pict1.bmp width=20 height=$v> ";
echo "<img src=pict1.bmp width=20 height=$r> ";
echo "<img src=pict1.bmp width=20 height=$d> ";

?>