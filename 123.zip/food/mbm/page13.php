<?php
$n=$_POST['n1'];
$a=1;
do
{
echo "$a<br>";
$a=$a+1;
}while($a<=$n);

?>