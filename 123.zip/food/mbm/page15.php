<?php
$n=$_POST['n1'];
for($a=1;$a<=10;$a++)
{
$c=$n*$a;
echo "$c<br>";
}
?>